import React from 'react';
import "./App.css";
import Navbar from "./components/navbar/navbar.component.js";
import TabsList from './components/tabsList/tabsList.component';
import {tabData,tableData} from "./data/tabData";
import ContentForPlans from './components/contentForPlans/contentForPlans.component';

class App extends React.Component {
  constructor() {
    super();
    this.state={
      data:[],
      dataForTable:[],
      pathName:''
    }
    this.changePathName=this.changePathName.bind(this);
  }
  componentDidMount()
  {
    //calling all the json tab data
    this.setState({data:tabData,dataForTable:tableData});
  }
  changePathName(e)
  {
    this.setState({pathName:e})
  }
  render() {

    var {data,dataForTable,pathName}=this.state;

    return (
      <div className="App">
        <Navbar path={pathName}></Navbar>
        <TabsList tabsData={data} changePath={this.changePathName}></TabsList>
        <ContentForPlans countryDataForTables={dataForTable}></ContentForPlans>     
      </div>
    );
  }
}

export default App;
