import React from "react";
import "./contentForPlans.component.css";
import worldImg from "../../assets/world.png";
function ContentForPlans({ countryDataForTables }) {
    var tableData;
    
    return (
    <div className="contentBody">
        <div id="shareOfSearch">
            <div className="worldImg">
                <p>Share of Search Per Country</p>
                <img src={worldImg}></img>
            </div>
            <div className="tableContent">
                <p>Number of Keyword per Country</p>
                <table>
                    <tr>
                        <th>Country Name</th>
                        <th>Number Of Keywords</th>
                        <th>Share Of Search</th>
                    </tr>

                     {tableData = countryDataForTables.map(items => 
                     <tr key={items.name}>
                        <td>{items.name}</td>
                        <td><a href="#">{items.keywords}</a></td>
                        <td>{items.percentage}</td>
                        </tr>)}
                
                </table>

            </div>
        </div>
        <div id="contentCompliance">

        </div>
    </div>

    );
}
export default ContentForPlans;