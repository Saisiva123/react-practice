import React from "react";
import "./navbar.component.css";
import hpLogo from "../../assets/hpLogo.png";
import calenderLogo from "../../assets/calender.png";

function Navbar(props) {
    var initialPathName = props.path ? props.path : "Content Compliance";
    return (
        <div className="navbar">
            <div className="header">
                <img src={hpLogo}></img>
                <ul>
                    <li>Overview</li>
                    <li>Competitor Analysis</li>
                    <li>Promotion Analysis</li>
                    <li>Brand Registry</li>
                </ul>
            </div>
            <div className="navbarContent">
                <div className="selectionBox">
                    <div id="selectDates">
                        <img src={calenderLogo}></img>
                        <div id="fromDate">
                            <select name="date">
                                <option >01 Jan 2020</option>
                                <option >02 Jan 2020</option>
                                <option >03 Jan 2020</option>
                            </select>
                        </div>
                        <div id="toDate">
                            <select name="date">
                                <option >30 Apr 2020</option>
                            </select>
                        </div>
                    </div>
                    <div id="selectCountryInfo">
                        <div id="countryName">
                            <select name="Country">
                                <option value="world">WorldWide</option>
                                <option value="india">India</option>
                                <option value="america">America</option>
                                <option value="china">China</option>
                                <option value="japan">Japan</option>
                            </select>
                        </div>
                        <div id="categoryName">
                            <select name="Category">
                                <option value="categories">All Categories</option>
                                <option value="india">India</option>
                                <option value="america">America</option>
                                <option value="china">China</option>
                                <option value="japan">Japan</option>
                            </select>
                        </div>
                        <div id="brandName">
                            <select name="brand" >
                                <option value="categories">HP Brand</option>
                                <option value="india">Lenovo</option>
                                <option value="america">Dell</option>
                            </select>
                        </div>
                    </div>

                </div>
                <div className="pathNames">
                    <i className='fas fa-long-arrow-alt-left'></i>
                    <div id="pathName1"><p>{initialPathName}</p></div>
                    <div id="pathName2"><p>Worldwide Overview</p></div>
                </div>
            </div>
        </div>

    );
}
export default Navbar;