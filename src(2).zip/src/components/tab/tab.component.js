import React from "react";
import "./tab.component.css";

function Tab(props)
{
    function callFuncToChangePath()
    {
         props.changeThePath(props.heading);
    }
    return (
        <div className="tab" onClick={callFuncToChangePath}>
            <p id="tabHeader">{props.heading}</p>
            <div id="price"><p>{props.price}</p></div>
            <p id="tag">{props.tag}</p>
        </div>
    );
}
export default Tab;