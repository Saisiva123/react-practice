import React from "react";
import "./tabsList.component.css";
import Tab from "../tab/tab.component.js";

function TabsList(props) {
    var listOfTabs;
    return (
        <div className="tabsList">
            {
                listOfTabs=props.tabsData.map(item => <Tab key={item.price} changeThePath={props.changePath} price={item.price} tag={item.tag} arrow={item.arrow} heading={item.tabHeader}></Tab>)
            }
        </div>
    );
}
export default TabsList; 