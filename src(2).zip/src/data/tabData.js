const tabData=[
    {
        tabHeader:"Product Availability",
        price:"56%",
        arrow:"down",
        tag:"19% less than target 75%"
    },
    {
        tabHeader:"Seller Analysis",
        price:"10%",
        icon:"up",
        tag:"10% increase in Unauthorized Sellers"
    },
    {
        tabHeader:"Price Variance",
        price:"12%",
        icon:"up",
        tag:"4.56k products with increased price"
    },
    {
        tabHeader:"Content Compliance",
        price:"65%",
        icon:"down",
        tag:"12% Authorized Sellers violating"
    },
    {
        tabHeader:"Share of Search",
        price:"48%",
        icon:"down",
        tag:"02% less thantarget 50%"
    },
    {
        tabHeader:"Reviews",
        price:"16.2M",
        icon:"down",
        tag:"10% Reviews contains -ve keywords"
    },
    {
        tabHeader:"Ratings",
        price:"4.3",
        icon:"up",
        tag:"60% Ratings are above 4 stars"
    }
];
const tableData=[
    {
        name:"India",
        keywords:"67 Keywords",
        percentage:"52%"
    },
    {
        name:"Australia",
        keywords:"53 Keywords",
        percentage:"48%"
    },
    {
        name:"Indonesia",
        keywords:"60 Keywords",
        percentage:"45%"
    },
    {
        name:"Thailand",
        keywords:"59 Keywords",
        percentage:"43%"
    },
    {
        name:"Japan",
        keywords:"57 Keywords",
        percentage:"52%"
    }
]
export  {tabData,tableData};