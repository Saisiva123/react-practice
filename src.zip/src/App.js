import React from "react";
import { monsterData, colors } from "./data/data.js";
import SearchBox from "./components/searchBox/searchBox.component.js";
import CardList from "./components/cardList/cardList.component.js";
import Login from "./components/login/login.component.js";
import Register from "./components/register/register.component.js";
import "./App.css";
class App extends React.Component {
  constructor() {
    super();
    this.state = {
      monsters: [],
      searchField: "",
      themeColor: "",
      loginEnable: false,
      registerEnable: false
    };

    this.storeValue = this.storeValue.bind(this);
    this.showLogin = this.showLogin.bind(this);
    this.showRegister = this.showRegister.bind(this);
  }
  // calls only once when the component is loaded(mainly used to get data from api)
  componentDidMount() {
    this.setState({ monsters: monsterData, themeColor: colors.bgColor });
    // fetch("").then(response=>respaonse.json()).then(data=>this.setState({}))
  }
  storeValue(e) {
    this.setState({ searchField: e.target.value });
    console.log(this.state.searchField);
    //asynchronous function is taking place ,we have to use call back functions
    //Ex:
    //this.setState({searchField:searchValue},()=>{console.log(this.stte.searchField)});
  }
  showLogin() {
    let loginStatus = !this.state.loginEnable;
    this.setState({ loginEnable: loginStatus })
    this.setState({ registerEnable: false })
  }
  showRegister() {
    let registerStatus = !this.state.registerEnable;
    this.setState({ registerEnable: registerStatus })
    this.setState({ loginEnable: false })
  }
  ifLogged()
  {
    alert("loggedin");
  }

  render() {
    var { registerEnable, loginEnable } = this.state;
    var showProfile;
    var bgColor = this.state.themeColor, headerColor = colors.headerBgColor;
    const { monsters, searchField } = this.state;
    const filteredSearchValue = monsters.filter(items =>
      items.name.toLowerCase().includes(searchField.toLowerCase()));
    return (

      <div className="App" style={{ backgroundColor: bgColor }} >
        <div className="header" style={{ backgroundColor: headerColor }}><h1>MONSTER APPLICATION</h1>
          <div className="signIn">
            <a onClick={this.showLogin}>LOGIN</a>
            <a onClick={this.showRegister}>REGISTER</a>
          </div></div>
        <SearchBox placeholder="Search Monsters" actionDone={this.storeValue}></SearchBox>
        <CardList monsters={filteredSearchValue}></CardList>
        {loginEnable ? <Login loggedIn={this.ifLogged}></Login> : null}
        {registerEnable ? <Register handleEvent={this.showLogin} ></Register> : null}
        
      </div>
    );
  }
}

export default App;
