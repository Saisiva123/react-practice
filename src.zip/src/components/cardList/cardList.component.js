import React from "react";
import Card from "../cards/card.component.js";
import  "./cardList.component.css";
const CardList = props => (
    <div className="cardContainer">
        {
            props.monsters.map(item => <Card key={item.key} monsters={item}></Card>)
        }
    </div>
)

export default CardList;