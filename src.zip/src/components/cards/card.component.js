import React from "react";
import "./card.component.css";
import {monsterData,colors} from  "../../data/data.js";

function Card(props)
{
    let cardBgColor=colors.cardColor;
    let imgLinks="https://robohash.org/"+props.monsters.key;
    
  return (  
    <div className="cards" style={{backgroundColor:cardBgColor}}>
        <img src={imgLinks}></img>
        <p id="name">{props.monsters.name}</p>
        <p id="mail">{props.monsters.email}</p>
    </div>
)
}
export default Card;