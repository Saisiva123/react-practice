import React from "react";
import "./login.component.css";


const Login=()=>
{
var checkLogin=true;
    return (
    <form className="formLogin" onSubmit={checkLogin?alert("true"):alert("false")}>
        <label>USERNAME:</label>
        <br></br>
        <input type="text"></input>
        <br></br>
        <label>PASSWORD:</label>
        <br></br>
        <input type="password"></input>
        <br></br>
        <button id="login">LOGIN</button>
    </form>
);
    }
export default Login;