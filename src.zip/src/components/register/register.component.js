import React from "react";
import "./register.component.css";

class Register extends React.Component
{
    constructor()
    {
        super();
        this.state=
        {
            email:'',
            password:''
        }
        this.saveUsername=this.saveUsername.bind(this);
        this.savePassword=this.savePassword.bind(this);
    }
    saveRegisterData()
    {
      
    }
    saveUsername(e)
    {
        let username=e.target.value;
        this.setState({email:username});
    }
    savePassword(e)
    {
        let password=e.target.value;
        this.setState({password:password})
    }
    render()
    {
        var {email,password}=this.state;
        return (
            <form>
            <label>First Name</label>
            <br></br>
            <input type="text" placeholder="first name"></input>
            <br></br>
            <label>LAST NAME:</label>
            <br></br>
            <input type="text" placeholder="last name"></input>
            <br></br>
            <label>EMAIL:</label>
            <br></br>
            <input type="text" placeholder="email" onChange={this.saveUsername}></input>
            <br></br>
            <label>PASSWORD:</label>
            <br></br>
            <input type="password" placeholder="password" onChange={this.savePassword}></input>
            <br></br>
            <button onClick={this.saveRegisterData}>REGISTER</button>
            <p>Already a member  |</p><a onClick={this.props.handleEvent}>Login</a>
            </form>
        )
    }
}
export default Register;