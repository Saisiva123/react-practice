import React from "react";
import "./searchBox.component.css";
//props can be accessed like this also bit angular concept
function SearchBox({placeholder,actionDone})
{
    return (
        <input type="search" onChange={actionDone} placeholder={placeholder}></input> 
    );
} 
export default SearchBox;