const monsterData=[
    {
        name:'SAI',
        email:'mannem.sai99@gmail.com',
        key:1
    },
    {
        name:'SIVA',
        email:'siva.sai99@gmail.com',
        key:2
    },
    {
        name:'DURGA',
        email:'durga.sai99@gmail.com',
        key:3
    },
    {
        name:'PRASAD',
        email:'prasad.sai99@gmail.com',
        key:4
    },
    {
        name:'ADARSH',
        email:'adarsh.sai99@gmail.com',
        key:5
    },
    {
        name:'DILEEP',
        email:'dileep.sai99@gmail.com',
        key:6
    },
    {
        name:'MANIKYAM',
        email:'manikyam.sai99@gmail.com',
        key:7
    },
    {
        name:'RAHUL',
        email:'rahul.sai99@gmail.com',
        key:8
    }
];
const colors=
{
    bgColor:"#242E39",
    cardColor:"#3B4D60",
    txtColor:"white",
    headerBgColor:"#2E3A46"
}
const users=[
    {
        email:'',
        password:''
    }

]
//["#242E39","#2E3A46","#FFC200","#3B4D60"];
export {monsterData,colors,users};